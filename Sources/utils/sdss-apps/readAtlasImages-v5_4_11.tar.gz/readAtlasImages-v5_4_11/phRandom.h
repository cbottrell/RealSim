#if !defined(PHRANDOM_H)
#define PHRANDOM_H

typedef void *RANDOM;

#endif
