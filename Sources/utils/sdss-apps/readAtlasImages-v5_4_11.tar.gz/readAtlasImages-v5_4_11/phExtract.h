#define NANN 1
